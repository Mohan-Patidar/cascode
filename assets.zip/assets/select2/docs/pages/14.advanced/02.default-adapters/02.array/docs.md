---
title: Array
taxonomy:
    category: docs
---

The `ArrayAdapter` implements support for creating results based on an [array of data objects](/data-sources/arrays).

**AMD Modules:**

`select2/data/array`
